package acdc;
import javax.swing.tree.DefaultMutableTreeNode;

public interface Inducer 
{
	public void induce(DefaultMutableTreeNode root);
}
